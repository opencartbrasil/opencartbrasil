<?php
// Text
$_['text_title']       = 'Pickup';
$_['text_description'] = 'Pickup From Store';