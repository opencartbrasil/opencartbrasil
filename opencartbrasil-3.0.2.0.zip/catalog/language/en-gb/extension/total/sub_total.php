<?php
// Text
$_['text_sub_total'] = 'Sub-Total';