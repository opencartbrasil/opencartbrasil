<?php
// Calculator
$_['text_checkout_title']      = 'Pagar parcelado';
$_['text_choose_plan']         = 'Selecione o plano';
$_['text_choose_deposit']      = 'Selecione o depósito';
$_['text_monthly_payments']    = 'pagamentos mensais de';
$_['text_months']              = 'meses';
$_['text_term']                = 'Termos';
$_['text_deposit']             = 'Depósito';
$_['text_credit_amount']       = 'Custo do crédito';
$_['text_amount_payable']      = 'Total a pagar';
$_['text_total_interest']      = 'Total de juros APR';
$_['text_monthly_installment'] = 'Prestação mensal';
$_['text_redirection']         = 'Você será redirecionado para o ambiente seguro da Divido, assim que confirmar o pedido.';