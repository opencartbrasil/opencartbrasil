<?php
// Heading
$_['heading_title']				   = 'Klarna Checkout';
$_['heading_title_success']		   = 'Your Klarna Checkout order has been placed!';

// Text
$_['text_title']				   = 'Klarna Checkout';
$_['text_basket']				   = 'Shopping Cart';
$_['text_checkout']				   = 'Checkout';
$_['text_success']				   = 'Success';
$_['text_choose_shipping_method']  = 'Choose shipping method';
$_['text_sales_tax']			   = 'Sales Tax';
$_['text_newsletter']			   = 'Subscribe to our newsletter';