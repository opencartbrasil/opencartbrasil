<?php
// Text
$_['text_handling'] = 'Taxa de manuseio';