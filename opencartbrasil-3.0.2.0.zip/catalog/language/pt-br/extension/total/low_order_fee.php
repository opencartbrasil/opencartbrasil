<?php
// Text
$_['text_low_order_fee'] = 'Taxa para pequenos pedidos';