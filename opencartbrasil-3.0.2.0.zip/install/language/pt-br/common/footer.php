<?php
// Text
$_['text_project']       = 'Página oficial';
$_['text_documentation'] = 'Documentação';
$_['text_support']       = 'Fórum';
$_['text_footer']        = 'Copyright © 2014 OpenCart - Todos os direitos reservados.';